"""
Implementazione di utilities relative alla lettura e deserializzazione file pickle
Todo:
    Add examples
"""
import sys
import pickle
import pandas as pd
import os
from pathlib import Path


def read_pck(file_name: str):
    """
    Funzione di lettura e deserializzazione di un singolo file pickle. Ritorna il contenuto del file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html)
    Args:
        file_name: path del file da legger

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt = pd.DataFrame()
    infile = open(file_name, 'rb')
    try:
        _dt = pickle.load(infile)
    except pickle.UnpicklingError:
        print('An error occured during file reading')
    infile.close()
    return _dt

def restricted_read_pck(file_name: str, columns: list):
    """
    Funzione di lettura e deserializzazione di un singolo file pickle. Ritorna il contenuto del file relativo alle colonne specficate come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).

    Args:
        file_name(str): path del file da leggere
        columns: lista delle colonne da tornare

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file

    """
    _dt = pd.DataFrame()
    infile = open(file_name, 'rb')
    try:
        _dt = pickle.load(infile)[columns]
    except pickle.UnpicklingError:
        print('An error occured during file reading')
    infile.close()
    
    return _dt    


def read_pcks(folder_name: str):
    """
    Funzione di scan e deserializzazione di una cartella di file pickle. Ritorna il contenuto dei file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html)

    Args:
        folder_name: path della cartella dove eseguire lo scan

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file

    """
    _dt_all = pd.DataFrame()
    for dirpath, dirnames, files in os.walk(folder_name):
        for file_name in files:
            _file_name = dirpath + os.path.sep + file_name
            #print('Parse: ' + _file_name)
            infile = open(_file_name, 'rb')
            try:
                _dt = pickle.load(infile)
                _dt_all = _dt_all.append(_dt, ignore_index=True)
            except pickle.UnpicklingError:
                print('Unhandle value error')
                continue
            infile.close()
        for dir_name in dirnames:
            _dir_name = dirpath + os.path.sep + dir_name
            print('Start Parse: ' + _dir_name)
            _dt = read_pcks(_dir_name)
            _dt_all = _dt_all.append(_dt, ignore_index=True)
            print('End parse: ' + _dir_name)
    return _dt_all



def restricted_read_pcks(folder_name: str, columns: list):
    """
    Funzione di scan e deserializzazione di una cartella di file pickle. Ritorna il contenuto dei file relativo alle colonne specficate come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).

    Args:
        folder_name: path della cartella dove esegire lo scan.
        columns: lista delle colonne da tornare

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()

    for dirpath, dirnames, files in os.walk(folder_name):
        for file_name in files:
            infile = open(dirpath + os.path.sep + file_name, 'rb')
            try:
                _dt = pickle.load(infile)[columns]
                _dt_all = _dt_all.append(_dt, ignore_index=True)
            except pickle.UnpicklingError:
                print('Unhandle value error')
                continue
            infile.close()
        for dir_name in dirnames:
            print('Start: ' + dir_name)
            _dt = restricted_read_pcks(dirpath +os.path.sep + dir_name, columns)
            _dt_all = _dt_all.append(_dt, ignore_index=True)
            print('End: ' + dir_name)
    return _dt_all    



def multi_read_pck(paths_to_scan:list):
    """
    Funzione di scan e de-serializzazione di un'insieme di file pickle. Ritorna il contenuto dei file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).

    Args:
        paths_to_scan: path della cartella dove esegire lo scan.

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file 
    """
    _dt_all = pd.DataFrame()
    for c_path in paths_to_scan:
        if os.path.isdir(c_path):
            _dt = multi_read_pck(os.listdir(c_path))
        else:
            infile = open(c_path, 'rb')
            _dt = pickle.load(infile)
            infile.close() 
        
        _dt_all = _dt_all.append(_dt, ignore_index=True)
    return _dt_all


def restricted_mult_read_pck(paths_to_scan: list, columns: list):
    """
    Funzione di scan e de-serializzazione di un'insieme di file pickle. Ritorna il contenuto dei file relativo alle colonne specficate come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).

    Args:
        paths_to_scan: path della cartella dove esegire lo scan.
        columns: lista delle colone da tornare

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()
    for c_path in paths_to_scan:
        if os.path.isdir(c_path):
            _dt = restricted_mult_read_pck(os.listdir(c_path), columns)
        else:
            infile = open(c_path, 'rb')
            _dt = pickle.load(infile)[columns]
            infile.close()
        _dt_all = _dt_all.append(_dt, ignore_index=True)
    return _dt_all
