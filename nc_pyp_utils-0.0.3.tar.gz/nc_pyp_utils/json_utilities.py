"""
Implementazione di utilities relative al load file json
Todo:
    Add examples
"""
import pandas as pd 
import sys
import os


def read_json(file_name: str):
    """
    Funzione di loading di un singolo file json. Ritorna il contenuto del file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html)
    Args:
        file_name: path del file da leggere

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _df = pd.read_json(file_name)
    return _df

def restricted_read_json(file_name: str, columns: list):
    """
    Funzione di loading di un singolo file json. Ritorna il contenuto del file relativo ai solo json properties sepcificati, come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).
    Args:
        file_name: path del file da leggere
        columns: lista dei json properties da tornare

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _df = pd.read_json(file_name)
    return _df[columns]

def read_jsons(folder_path: str):
    """
    Funzione di scan e loading di una cartella contenent file json. Ritorna il contenuto dei file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).
    Args:
        folder_path: path della cartella

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()
    
    for dirpath, dirnames, files in os.walk(folder_path):
        for file_name in files:
            try:
                _dt = pd.read_json(dirpath + os.path.sep + file_name)
                _dt_all = _dt_all.append(_dt, ignore_index=True)
            except ValueError:
                print('Unhandle value error')
                continue
    return _dt_all
    
def restricted_read_jsons(folder_path: str, columns: list):
    """
    Funzione di scan e loading di una cartella contenent file json. Ritorna il contenuto dei file relativo ai json properties sepcificati, come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).
    Args:
        file_name: path della cartella
        columns: lista delle json properties
    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()
    
    for dirpath, dirnames, files in os.walk(folder_path):
        for file_name in files:
            try:
                _dt = pd.read_json(dirpath + os.path.sep +  file_name)[columns]
                _dt_all = _dt_all.append(_dt, ignore_index=True)
            except ValueError:
                print('Unhandle value error')
                continue
    return _dt_all

def multi_read_json(paths_to_scan:list ):
    """
    Funzione di scan e loading di una insieme di file json. Ritorna il contenuto dei file, relativo ai json properties specificati, come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).
    Args:
        paths_to_scan: insieme dei path dei file da leggere

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()
    for c_path in paths_to_scan:
        if os.path.isdir(c_path):
            _dt = multi_read_json(os.listdir(c_path ))
        else:
            _dt = pd.read_json(c_path)
        
        _dt_all = _dt_all.append(_dt, ignore_index=True)

    return _dt_all

def restricted_mult_read_json(paths_to_scan: list, columns: list):
    """
    Funzione di scan e loading di una insieme di file json. Ritorna il contenuto dei file come un 
    DataFrame (https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.html).
    Args:
        paths_to_scan: insieme dei path dei file da leggere

    Returns:
        pd.DataFrame: dati colonnari contenuti nel file
    """
    _dt_all = pd.DataFrame()
    for c_path in paths_to_scan:
        if os.path.isdir(c_path):
            _dt = restricted_mult_read_json(os.listdir(c_path), columns)
        else:
            _dt = pd.read_json(c_path)
        _dt_all = _dt_all.append(_dt, ignore_index=True)
    return _dt_all

def main():
        _df = read_jsons('/home/ariona/c-bas-datalake/twitter/trulli')
        print(_df.info())

if __name__ == "__main__":
    main()


