import re
import pandas as pd
import plotly.offline as py
import plotly.graph_objs as go
import plotly.tools as tls
from matplotlib import pyplot as plt

REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')

def clean_text(text: str, stop_words):
    text = text.lower() 
    text = REPLACE_BY_SPACE_RE.sub(' ', text)
    text = BAD_SYMBOLS_RE.sub('', text)  
    text = text.replace('x', '')
    text = ' '.join(word for word in text.split() if word not in stop_words)
    return text

def load_data(fileinput, merge):
    raw_data = pd.read_json('testcases/training.json', lines=True)
    if merge is True:
        raw_data['question'] = raw_data[['question', 'excerpt']].apply(lambda x: ' '.join(x), axis=1)
    return raw_data


def load_data_test(filein, fileout):
    data_test_in = pd.read_json(filein, lines=True)
    data_test_out = pd.read_csv(fileout)
    data_test = pd.merge(data_test_in, data_test_out, left_index=True, right_index=True)
    
    return data_test

def show(data: pd.Series, tit: str, tot: int):
    w_count = data.str.split(expand=True).unstack().value_counts()
    data = [go.Bar(
            x = w_count.index.values[2:tot],
            y = w_count.values[2:tot],
            marker= dict(colorscale='Jet',
                         color = w_count.values[2:tot]
                        ),
            text='word freq'
    )]
    layout = go.Layout(
        title=tit)
    fig = go.Figure(data=data, layout=layout)
    py.iplot(fig, filename='basic-bar')

