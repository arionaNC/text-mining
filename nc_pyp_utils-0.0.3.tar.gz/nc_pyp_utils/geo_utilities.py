"""
Implementazione di utilities relative al retrive geolocalizzazione twitter entries
Todo:
    Add examples
"""
import pandas as pd
from geopy.geocoders import Nominatim

class GeoOrigin:
    
    def __init__(self):
        self.country_code = pd.read_csv('country_code.csv')
        self.gelocator = Nominatim()

    def populate_origin(self, user: dict):
        _loc=''
        try:
            _loc = user.get('location')
            _locs = _loc.split()
            try:
                _search = self.country_code[self.country_code['Native Name'].str.contains(_locs[len(_locs) -1], na=False)].iloc[0]['Code']
            except IndexError:
                _search = self.country_code[self.country_code['Name'].str.contains(_locs[len(_locs) -1], na=False)].iloc[0]['Code']
            return _search
        except Exception as e:
            return _loc

    def geopopulate_origin(self, user: dict):
        try:
            _loc = user.get('location')
            _geoloc = self.gelocator.geocode(_loc)
            _locs = _geoloc.split()
            try:
                _search = self.country_code[self.country_code['Native Name'].str.contains(_locs[len(_locs) -1], na=False)].iloc[0]['Code']
            except IndexError:
                _search = self.country_code[self.country_code['Name'].str.contains(_locs[len(_locs) -1], na=False)].iloc[0]['Code']
            return _search
        except Exception as e:
            return _loc
